'use strict'

// Declare angular app paramaters
var app = angular.module('chiddybang', []);
